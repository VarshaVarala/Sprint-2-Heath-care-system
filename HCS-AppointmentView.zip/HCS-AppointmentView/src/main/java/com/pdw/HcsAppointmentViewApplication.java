package com.pdw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HcsAppointmentViewApplication {

	public static void main(String[] args) {
		SpringApplication.run(HcsAppointmentViewApplication.class, args);
	}

}

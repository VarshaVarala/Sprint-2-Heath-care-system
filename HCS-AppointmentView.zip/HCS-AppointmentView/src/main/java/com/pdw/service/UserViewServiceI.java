package com.pdw.service;

import java.util.List;

import com.pdw.entity.Appointments;

public interface UserViewServiceI {

	List<Appointments> AppointmentList();

}

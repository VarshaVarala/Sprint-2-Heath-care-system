package com.pdw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HcsApproveAppointmentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HcsApproveAppointmentsApplication.class, args);
	}

}

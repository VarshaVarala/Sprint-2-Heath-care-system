package com.pdw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HcsUserAppointmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(HcsUserAppointmentApplication.class, args);
	}
	
	
}
